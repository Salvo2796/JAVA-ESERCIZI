public class DataTest {
    public static void main (String args[]) {
        Data miaData = new Data();
        miaData.giorno = 7;
        miaData.mostraGiorno();
    }
}